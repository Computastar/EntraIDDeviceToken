using namespace System.Net
using namespace System.Security
using namespace System.Security.Cryptography
using namespace System.Security.Cryptography.X509Certificates

param($Request, $TriggerMetadata)

function deconstructCertificate {
    param($certificate)

    $certificateProperties = [ordered]@{
        Subject         = $certificate.Subject
        Issuer          = $certificate.Issuer
        Thumbprint      = $certificate.Thumbprint
        SerialNumber    = $certificate.SerialNumber
        ExpirationDate  = $certificate.NotAfter
        StartDate       = $certificate.NotBefore
        FriendlyName    = $certificate.FriendlyName
        Version         = $certificate.Version
        PublicKey       = $certificate.GetPublicKey()
    }

    $extensions = $certificate.Extensions
    foreach ($extension in $extensions) {
        $oidValue = $extension.Oid.Value
        $rawData = $extension.RawData
        $trimmedByteArray = $rawData[3..($rawData.Count - 1)]

        if ($rawData.Count -ge 19) {
            [System.Array]::Reverse($trimmedByteArray, 0, 4)
            [System.Array]::Reverse($trimmedByteArray, 4, 2)
            [System.Array]::Reverse($trimmedByteArray, 6, 2)
        }

        $hexString = -join ($trimmedByteArray | ForEach-Object { "{0:X2}" -f $_ })

        switch ($oidValue) {
            "1.2.840.113556.1.5.284.2" { $certificateProperties.DeviceId = [System.Guid]::New($hexString).ToString() }
            "1.2.840.113556.1.5.284.3" { $certificateProperties.UserId = [System.Guid]::New($hexString).ToString() }
            "1.2.840.113556.1.5.284.5" { $certificateProperties.TenantId = [System.Guid]::New($hexString).ToString() }
            "1.2.840.113556.1.5.284.8" { $certificateProperties.Location = [System.Text.Encoding]::UTF8.GetString($trimmedByteArray) }
            "1.2.840.113556.1.5.284.7" { $certificateProperties.JoinStatus = [System.Text.Encoding]::UTF8.GetString($trimmedByteArray) }
        }
    }

    return $certificateProperties
}

function Get-TenantRegion {
    param ($TenantId)
    $query = Invoke-RestMethod "https://login.microsoftonline.com/$TenantId/.well-known/openid-configuration"
    return $query.tenant_region_scope
}

function Get-AzureADToken {
    param (
        [Parameter(Mandatory = $true)] [string] $TenantId,
        [Parameter(Mandatory = $true)] [string] $ClientAppId,
        [Parameter(Mandatory = $true)] [string] $ClientSecret,
        [Parameter(Mandatory = $true)] [string] $Scope
    )

    $tokenEndpoint = "https://login.microsoftonline.com/$TenantId/oauth2/v2.0/token"
    $tokenRequestBody = "client_id=$ClientAppId&client_secret=$ClientSecret&scope=$Scope&grant_type=client_credentials"
    $headers = @{
        "Content-Type" = "application/x-www-form-urlencoded"
    }

    try {
        $tokenResponse = (Invoke-RestMethod -Uri $tokenEndpoint -Method "Post" -Body $tokenRequestBody -Headers $headers).access_token
        return $tokenResponse
    } catch {
        throw "Failed to acquire access token: $_"
    }
}

function Get-Certificate {
    $clientCertRawData = $Request.Headers
    $certHeader = $clientCertRawData["X-ARR-ClientCert"]

    if ($certHeader -ne $null) {
        [byte[]] $clientCertBytes = [Convert]::FromBase64String($certHeader)
        return [System.Security.Cryptography.X509Certificates.X509Certificate2]::New($clientCertBytes)
    } else {
        $Response = @{
            status  = [HttpStatusCode]::NotFound
            message = "Certificate not found"
        }
        return ReturnResponse($Response)
    }
}

function Get-ManagedIdentityToken {
    param (
        [Parameter(Mandatory = $true)]
        [string] $Resource
    )
    $tokenUrl = "http://169.254.169.254/metadata/identity/oauth2/token"
    $headers = @{
        Metadata = "true"
    }
    $params = @{
        resource = $Resource
        "api-version" = "2018-02-01"
    }
    try {
        $response = Invoke-RestMethod -Uri "$tokenUrl?$(($params.GetEnumerator() | ForEach-Object { "$($_.Key)=$($_.Value)" }) -join '&')" -Method Get -Headers $headers
        return $response.access_token
    } catch {
        throw "Failed to acquire managed identity token: $_"
    }
}

function Check-TenantId {
    param ([Parameter(Mandatory = $true)] $certificateTenantId)
    $envTenantId = $env:WEBSITE_AUTH_AAD_ALLOWED_TENANTS
    return $envTenantId -eq $certificateTenantId
}

function Check-DeviceExists {
    param (
        [Parameter(Mandatory = $true)] $certificateDeviceId,
        [Parameter(Mandatory = $true)] $tenantDeviceId
    )
    return $certificateDeviceId -eq $tenantDeviceId
}

function Check-SecurityIdAgainstThumbprint {
    $sha1 = New-Object System.Security.Cryptography.SHA256Managed
    $hashBytes = $sha1.ComputeHash($certificate.PublicKey)
    $certificatePublicKey = [Convert]::ToBase64String($hashBytes)
    $certificateSecurityIds = "X509:<SHA1-TP-PUBKEY>$($certificate.Thumbprint)$certificatePublicKey"
    $tenantDevicealternativeSecurityIds = [Convert]::FromBase64String($tenantDeviceIdResponse.alternativeSecurityIds.key)
    $tenantDevicealternativeSecurityIds = [System.Text.Encoding]::UTF8.GetString($tenantDevicealternativeSecurityIds)
    return $certificateSecurityIds -eq $tenantDevicealternativeSecurityIds
}

function Check-Issuer {
    return $certificate.Issuer -eq "DC=net + DC=windows + CN=MS-Organization-Access + OU=82dbaca4-3e81-46ca-9c73-0950c1eaca97"
}

function Check-DeviceIsEntrIDJoined {
    return $certificate.JoinStatus -eq 1
}

function Check-CertIsNotExpired {
    return $certificate.NotAfter -lt (Get-Date)
}

function Check-DeviceCreationDate {
    return $certificate.NotBefore -eq $tenantDeviceIdResponse.createdDateTime
}

function Check-TenantRegion {
    return $certificate.Location -eq (Get-TenantRegion($env:WEBSITE_AUTH_AAD_ALLOWED_TENANTS))
}

function ReturnResponse {
    param($Response)
    $body = $Response
    Push-OutputBinding -Name Response -Value ([HttpResponseContext]@{
        StatusCode = $body.status
        Body       = @{
            message = $body.message
            token   = $body.token
        }
    })
    exit
}

$requestBody =  $Request.Body 
$appId = $requestBody.appId
$scope = $requestBody.scope

Write-Host "AppId: $appId Scope: $scope"

if (-not $appId -or -not $scope) {
    $Response = @{
        status  = [HttpStatusCode]::BadRequest
        message = "Please pass appId and scope in the request body"
    }
    return ReturnResponse($Response)
}

$certificate = deconstructCertificate(Get-Certificate)
if ($certificate -ne $null) {
    $CheckTenantRegion = Check-TenantRegion
    Write-Output "The device region matches the tenant region: $CheckTenantRegion"

    $CheckDeviceCreationDate = Check-DeviceCreationDate
    Write-Output "The device and certificate date match: $CheckDeviceCreationDate"

    $IsCertNotExpired = Check-CertIsNotExpired
    Write-Output "The certificate is not expired: $IsCertNotExpired"

    $IsIssuerValid = Check-Issuer
    Write-Output "The issuer is valid: $IsIssuerValid"

    $IsEntraIDJoined = Check-DeviceIsEntrIDJoined
    Write-Output "The device is EntraID joined: $IsEntraIDJoined"

    $IsTenantAllowed = Check-TenantId -certificateTenantId $certificate.TenantId
    Write-Output "The tenant is valid: $IsTenantAllowed"
} else {
    $Response = @{
        status  = [HttpStatusCode]::NotFound
        message = "Certificate not found"
    }
    return ReturnResponse($Response)
}


$tenantId = "2c326271-2dbb-42f6-b2e3-f675bb815bd4"
$clientAppId = $appId
$clientSecret = (Get-Item env:MICROSOFT_PROVIDER_AUTHENTICATION_SECRET).Value
$scopeGraph = [System.Web.HttpUtility]::UrlEncode("https://graph.microsoft.com/.default")

$accessToken = Get-AzureADToken -TenantId $tenantId -ClientAppId $clientAppId -ClientSecret $clientSecret -Scope $scopeGraph
$tenantDeviceIdURI = "https://graph.microsoft.com/v1.0/devices?`$filter=deviceId eq '$($certificate.DeviceId)'"
$tenantDeviceIdResponse = (Invoke-RestMethod -Method "Get" -Uri $tenantDeviceIdURI -ContentType "application/json" -Headers @{"Authorization" = "Bearer $accessToken"} -ErrorAction Stop).value

$DoesDeviceExist = Check-DeviceExists -certificateDeviceId $certificate.DeviceId -tenantDeviceId $tenantDeviceIdResponse.deviceId
Write-Output "The device does exist: $DoesDeviceExist"

$IsDeviceEnabled = $tenantDeviceIdResponse.accountEnabled
Write-Output "Device is enabled: $IsDeviceEnabled"

$IsSecurityIDValid = Check-SecurityIdAgainstThumbprint
Write-Output "Alternate IDs & Thumbprint match: $IsSecurityIDValid"

if ($IsIssuerValid -and $IsCertNotExpired -and $CheckTenantRegion -and $IsEntraIDJoined -and $IsTenantAllowed -and $DoesDeviceExist -and $IsDeviceEnabled -and $IsSecurityIDValid) {
    Write-Host "Client is valid, issue token."

    $accessToken = Get-AzureADToken -TenantId $tenantId -ClientAppId $clientAppId -ClientSecret $clientSecret -Scope $scope
    $Response = @{
        status  = [HttpStatusCode]::OK
        message = "Access token retrieved successfully"
        token   = $accessToken
    }
} else {
    Write-Host "Client validation failed."
    $Response = @{
        status  = [HttpStatusCode]::Forbidden
        message = "Client validation failed."
    }
}

ReturnResponse $Response
